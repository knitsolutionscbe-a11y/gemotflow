require('dotenv').config();
const bcrypt = require('bcryptjs');
const pool = require('./db');
const { uid } = require('./utils/helpers');

async function seed() {
  const { rows } = await pool.query("SELECT id FROM users WHERE username='superadmin'");
  if (!rows.length) {
    const hash = await bcrypt.hash(process.env.SEED_SUPERADMIN_PASSWORD || 'admin123', 10);
    await pool.query(
      `INSERT INTO users (id, username, password_hash, full_name, role, department, active)
       VALUES ($1,'superadmin',$2,'Super Administrator','superadmin','all',true)`,
      [uid('u'), hash]
    );
    console.log('Created default superadmin (username: superadmin) — CHANGE THE PASSWORD after first login.');
  } else {
    console.log('superadmin already exists, skipping user seed.');
  }

  const anesthesiaTypes = ['General', 'Spinal', 'Epidural', 'Regional / Nerve block', 'Local + sedation', 'Local'];
  for (const v of anesthesiaTypes) {
    await pool.query(
      "INSERT INTO masters (id, type, value) VALUES ($1,'anesthesia_type',$2) ON CONFLICT (type,value) DO NOTHING",
      [uid('m'), v]
    );
  }

  const { rows: wardRows } = await pool.query('SELECT id FROM wards');
  if (!wardRows.length) {
    await pool.query("INSERT INTO wards (id, name, floor) VALUES ($1,'Ward A','2nd Floor')", [uid('w')]);
    await pool.query("INSERT INTO wards (id, name, floor) VALUES ($1,'Ward B','3rd Floor')", [uid('w')]);
  }

  const { rows: otRows } = await pool.query('SELECT id FROM ots');
  if (!otRows.length) {
    for (let n = 1; n <= 7; n++) {
      await pool.query(
        "INSERT INTO ots (id, name, floor, status) VALUES ($1,$2,$3,'vacant')",
        [uid('ot'), `OT ${n}`, n <= 4 ? '1st Floor' : '2nd Floor']
      );
    }
  }

  const { rows: preopRows } = await pool.query('SELECT id FROM preop_bays');
  if (!preopRows.length) {
    for (let n = 1; n <= 7; n++) {
      await pool.query("INSERT INTO preop_bays (id, name, status) VALUES ($1,$2,'vacant')", [uid('pp'), `Pre-Op ${n}`]);
    }
  }

  const { rows: bedRows } = await pool.query('SELECT id FROM beds');
  if (!bedRows.length) {
    await pool.query("INSERT INTO beds (id, name, status) VALUES ($1,'Recovery 1','vacant')", [uid('bed')]);
    await pool.query("INSERT INTO beds (id, name, status) VALUES ($1,'Recovery 2','vacant')", [uid('bed')]);
  }

  console.log('Seed complete.');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
