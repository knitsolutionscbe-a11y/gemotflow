require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const morgan = require('morgan');

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));
app.use(morgan('dev'));

app.get('/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/wards', require('./routes/wards'));
app.use('/api/preop-bays', require('./routes/preopBays'));
app.use('/api/ots', require('./routes/ots'));
app.use('/api/beds', require('./routes/beds'));
app.use('/api/masters', require('./routes/masters'));
app.use('/api/item-catalog', require('./routes/itemCatalog'));
app.use('/api/surgery-packages', require('./routes/surgeryPackages'));
app.use('/api/ot-store', require('./routes/otStore'));
app.use('/api/integration', require('./routes/integration'));
app.use('/api/patients', require('./routes/patients'));
app.use('/api/bookings', require('./routes/bookings'));
app.use('/api/audit-log', require('./routes/auditLog'));
app.use('/api/reports', require('./routes/reports'));

app.use((req, res, next) => { if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found' }); next(); });

// Serve the frontend HTML app from the same server, so a single deployment
// (one Node process) hosts both the API and the UI — no separate static
// host, no CORS setup needed. Drop ot-patient-tracker.html into /public.
app.use(express.static(path.join(__dirname, '..', 'public')));
// Express 5's router (path-to-regexp v8) rejects a bare '*' pattern — a
// path-less middleware is the correct catch-all here instead.
app.use((req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'ot-patient-tracker.html'), err => {
    if (err) res.status(404).send('Frontend not found — place ot-patient-tracker.html in the /public folder.');
  });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error', detail: process.env.NODE_ENV === 'production' ? undefined : err.message });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`OT Flow listening on port ${PORT} (API + frontend)`));
