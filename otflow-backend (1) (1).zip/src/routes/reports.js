const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth, requireRole('superadmin', 'admin', 'manager', 'consultant'));

function mins(a, b) {
  if (!a || !b) return null;
  return Math.max(0, Math.round((new Date(b) - new Date(a)) / 60000));
}
function avg(arr) {
  const v = arr.filter(x => x != null);
  if (!v.length) return null;
  return Math.round(v.reduce((a, b) => a + b, 0) / v.length);
}

router.get('/', async (req, res) => {
  const from = req.query.from || new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10);
  const to = req.query.to || new Date().toISOString().slice(0, 10);
  const workingHours = Number(req.query.workingHours) || 12;

  const { rows: patients } = await pool.query(
    `SELECT p.*, o.name AS ot_name FROM patients p LEFT JOIN ots o ON o.id = p.assigned_ot_id
     WHERE p.ward_in IS NOT NULL AND p.ward_in >= $1 AND p.ward_in < ($2::date + interval '1 day')`,
    [from, to]
  );

  const rows = patients.map(p => ({
    name: p.name,
    otName: p.ot_name || p.ot_name_snapshot || '',
    wardIn: p.ward_in,
    preopWaitMins: mins(p.sent_to_preop_at, p.preop_in),
    preopMins: mins(p.preop_in, p.sent_to_ot_at),
    waitMins: mins(p.sent_to_ot_at, p.ot_in),
    anesMins: mins(p.anes_start, p.anes_end),
    surgMins: mins(p.surg_start, p.surg_end),
    otMins: mins(p.ot_in, p.ot_out),
    recMins: mins(p.recovery_in, p.ward_return || p.sent_to_ward_at),
    turnaroundMins: mins(p.ward_in, p.ward_return)
  }));

  const summary = {
    count: rows.length,
    avgTurnaround: avg(rows.map(r => r.turnaroundMins)),
    avgPreopWait: avg(rows.map(r => r.preopWaitMins)),
    avgPreop: avg(rows.map(r => r.preopMins)),
    avgWait: avg(rows.map(r => r.waitMins)),
    avgSurgery: avg(rows.map(r => r.surgMins)),
    avgAnes: avg(rows.map(r => r.anesMins)),
    avgOtOccupied: avg(rows.map(r => r.otMins)),
    avgRecovery: avg(rows.map(r => r.recMins))
  };

  const { rows: ots } = await pool.query('SELECT * FROM ots ORDER BY name');
  const days = Math.max(1, Math.round((new Date(to) - new Date(from)) / 86400000) + 1);
  const capacityMins = days * workingHours * 60;
  const utilization = [];
  for (const ot of ots) {
    const { rows: cases } = await pool.query(
      `SELECT ot_in, ot_out FROM patients WHERE assigned_ot_id=$1 AND ot_in IS NOT NULL AND ot_in >= $2 AND ot_in < ($3::date + interval '1 day')`,
      [ot.id, from, to]
    );
    const occupiedMins = cases.reduce((sum, c) => sum + (mins(c.ot_in, c.ot_out) || 0), 0);
    const utilPct = capacityMins > 0 ? Math.round((occupiedMins / capacityMins) * 1000) / 10 : 0;
    utilization.push({ name: ot.name, cases: cases.length, occupiedMins, capacityMins, utilPct });
  }

  res.json({ from, to, workingHours, rows, summary, utilization });
});

module.exports = router;
