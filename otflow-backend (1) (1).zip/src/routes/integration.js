const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

function toApi(row) {
  return {
    hmsApiUrl: row.hms_api_url || '',
    hmsApiKey: row.hms_api_key || '',
    hmsAuthHeader: row.hms_auth_header || 'Authorization',
    hmsAuthScheme: row.hms_auth_scheme || 'Bearer'
  };
}

router.get('/', requireRole('superadmin'), async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM integration_config WHERE id=1');
  res.json(toApi(rows[0] || {}));
});

router.put('/', requireRole('superadmin'), async (req, res) => {
  const { hmsApiUrl, hmsApiKey, hmsAuthHeader, hmsAuthScheme } = req.body || {};
  await pool.query(
    `UPDATE integration_config SET hms_api_url=$1, hms_api_key=$2, hms_auth_header=$3, hms_auth_scheme=$4 WHERE id=1`,
    [hmsApiUrl || '', hmsApiKey || '', hmsAuthHeader || 'Authorization', hmsAuthScheme || 'Bearer']
  );
  const { rows } = await pool.query('SELECT * FROM integration_config WHERE id=1');
  res.json(toApi(rows[0]));
});

router.post('/test', requireRole('superadmin'), async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM integration_config WHERE id=1');
  const cfg = rows[0];
  if (!cfg || !cfg.hms_api_url) return res.status(400).json({ error: 'No HMS API endpoint configured yet' });
  try {
    const headers = { 'Content-Type': 'application/json' };
    if (cfg.hms_api_key) headers[cfg.hms_auth_header || 'Authorization'] = (cfg.hms_auth_scheme ? cfg.hms_auth_scheme + ' ' : '') + cfg.hms_api_key;
    const hmsRes = await fetch(cfg.hms_api_url, { method: 'POST', headers, body: JSON.stringify({ test: true, sentAt: new Date().toISOString(), from: 'OT Flow test connection' }) });
    if (hmsRes.ok) return res.json({ ok: true, status: hmsRes.status });
    return res.status(502).json({ ok: false, error: `HTTP ${hmsRes.status}` });
  } catch (err) {
    return res.status(502).json({ ok: false, error: `Network/CORS error reaching HMS: ${err.message}` });
  }
});

module.exports = router;
