const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth, requireRole('superadmin', 'admin'));

router.get('/', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM audit_log ORDER BY at DESC');
  res.json(rows.map(r => ({
    id: r.id, at: r.at, byUser: r.by_user, byUserId: r.by_user_id, byRole: r.by_role,
    patientId: r.patient_id, patientName: r.patient_name, action: r.action, reason: r.reason
  })));
});

module.exports = router;
