const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');
const { JWT_SECRET, requireAuth } = require('../middleware/auth');
const { userRowToApi } = require('../utils/helpers');

const router = express.Router();

router.post('/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Username and password required' });
  const { rows } = await pool.query('SELECT * FROM users WHERE lower(username) = lower($1)', [username]);
  const user = rows[0];
  if (!user) return res.status(401).json({ error: 'Incorrect username or password' });
  if (!user.active) return res.status(401).json({ error: 'This account has been deactivated' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Incorrect username or password' });
  const token = jwt.sign({ sub: user.id, role: user.role }, JWT_SECRET, { expiresIn: '12h' });
  res.json({ token, user: userRowToApi(user) });
});

router.get('/me', requireAuth, (req, res) => {
  res.json({ user: userRowToApi(req.user) });
});

module.exports = router;
