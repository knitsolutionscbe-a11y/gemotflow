const express = require('express');
const bcrypt = require('bcryptjs');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { uid, userRowToApi } = require('../utils/helpers');

const router = express.Router();
router.use(requireAuth, requireRole('superadmin', 'admin'));

function assignableRoles(actorRole) {
  if (actorRole === 'superadmin') return ['admin', 'consultant', 'manager', 'user'];
  if (actorRole === 'admin') return ['consultant', 'manager', 'user'];
  return [];
}

router.get('/', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM users ORDER BY role, full_name');
  res.json(rows.map(userRowToApi));
});

router.post('/', async (req, res) => {
  const { username, password, fullName, role, department, assignedOtId, assignedWardId } = req.body || {};
  if (!username || !password || !fullName || !role) {
    return res.status(400).json({ error: 'username, password, fullName, and role are required' });
  }
  if (!assignableRoles(req.user.role).includes(role)) {
    return res.status(403).json({ error: 'You cannot assign that role' });
  }
  const { rows: existing } = await pool.query('SELECT id FROM users WHERE lower(username)=lower($1)', [username]);
  if (existing.length) return res.status(409).json({ error: 'Username already exists' });

  const id = uid('u');
  const finalDept = (role === 'superadmin' || role === 'admin') ? 'all' : (department || 'all');
  const finalOtId = finalDept === 'ot' ? (assignedOtId || null) : null;
  const finalWardId = finalDept === 'ward' ? (assignedWardId || null) : null;
  const hash = await bcrypt.hash(password, 10);
  await pool.query(
    `INSERT INTO users (id, username, password_hash, full_name, role, department, assigned_ot_id, assigned_ward_id, active, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,true,$9)`,
    [id, username, hash, fullName, role, finalDept, finalOtId, finalWardId, req.user.id]
  );
  const { rows } = await pool.query('SELECT * FROM users WHERE id=$1', [id]);
  res.status(201).json(userRowToApi(rows[0]));
});

router.put('/:id', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM users WHERE id=$1', [req.params.id]);
  const target = rows[0];
  if (!target) return res.status(404).json({ error: 'User not found' });
  if (req.user.role === 'admin' && target.role === 'superadmin') {
    return res.status(403).json({ error: 'Admins cannot edit Super Admin accounts' });
  }
  const { username, fullName, role, department, password, assignedOtId, assignedWardId } = req.body || {};
  const newRole = role || target.role;
  if (role && role !== target.role && !assignableRoles(req.user.role).includes(role)) {
    return res.status(403).json({ error: 'You cannot assign that role' });
  }
  const newDept = (newRole === 'superadmin' || newRole === 'admin') ? 'all' : (department || target.department);
  const newOtId = newDept === 'ot' ? (assignedOtId || null) : null;
  const newWardId = newDept === 'ward' ? (assignedWardId || null) : null;
  const newUsername = username || target.username;
  const newFullName = fullName || target.full_name;
  let passwordHash = target.password_hash;
  if (password) passwordHash = await bcrypt.hash(password, 10);

  await pool.query(
    `UPDATE users SET username=$1, full_name=$2, role=$3, department=$4, assigned_ot_id=$5, assigned_ward_id=$6, password_hash=$7 WHERE id=$8`,
    [newUsername, newFullName, newRole, newDept, newOtId, newWardId, passwordHash, req.params.id]
  );
  const { rows: updated } = await pool.query('SELECT * FROM users WHERE id=$1', [req.params.id]);
  res.json(userRowToApi(updated[0]));
});

router.patch('/:id/toggle-active', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM users WHERE id=$1', [req.params.id]);
  const target = rows[0];
  if (!target) return res.status(404).json({ error: 'User not found' });
  if (req.user.role === 'admin' && target.role === 'superadmin') {
    return res.status(403).json({ error: 'Admins cannot disable Super Admin accounts' });
  }
  if (target.id === req.user.id) return res.status(400).json({ error: 'You cannot disable your own account' });
  await pool.query('UPDATE users SET active = NOT active WHERE id=$1', [req.params.id]);
  const { rows: updated } = await pool.query('SELECT * FROM users WHERE id=$1', [req.params.id]);
  res.json(userRowToApi(updated[0]));
});

module.exports = router;
