const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { uid } = require('../utils/helpers');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM wards ORDER BY name');
  res.json(rows.map(w => ({ id: w.id, name: w.name, floor: w.floor })));
});

router.post('/', requireRole('superadmin', 'admin'), async (req, res) => {
  const { name, floor } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Ward name is required' });
  const id = uid('w');
  await pool.query('INSERT INTO wards (id, name, floor) VALUES ($1,$2,$3)', [id, name, floor || null]);
  res.status(201).json({ id, name, floor });
});

router.put('/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  const { name, floor } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Ward name is required' });
  await pool.query('UPDATE wards SET name=$1, floor=$2 WHERE id=$3', [name, floor || null, req.params.id]);
  res.json({ id: req.params.id, name, floor });
});

router.delete('/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  await pool.query('DELETE FROM wards WHERE id=$1', [req.params.id]);
  res.status(204).end();
});

// Rooms nested under a ward
router.get('/:wardId/rooms', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM rooms WHERE ward_id=$1 ORDER BY name', [req.params.wardId]);
  res.json(rows.map(r => ({ id: r.id, wardId: r.ward_id, name: r.name })));
});

router.post('/:wardId/rooms', requireRole('superadmin', 'admin'), async (req, res) => {
  const { name } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Room name is required' });
  const id = uid('rm');
  await pool.query('INSERT INTO rooms (id, ward_id, name) VALUES ($1,$2,$3)', [id, req.params.wardId, name]);
  res.status(201).json({ id, wardId: req.params.wardId, name });
});

router.put('/rooms/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  const { name } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Room name is required' });
  await pool.query('UPDATE rooms SET name=$1 WHERE id=$2', [name, req.params.id]);
  res.json({ id: req.params.id, name });
});

router.delete('/rooms/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  await pool.query('DELETE FROM rooms WHERE id=$1', [req.params.id]);
  res.status(204).end();
});

module.exports = router;
