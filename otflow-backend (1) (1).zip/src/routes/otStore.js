const express = require('express');
const pool = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

// Cross-patient queue of every item still sitting at "ordered", for OT Store staff.
router.get('/pending', async (req, res) => {
  const { rows } = await pool.query(
    `SELECT pio.*, p.name AS patient_name, p.id AS patient_id
     FROM patient_item_orders pio
     JOIN patients p ON p.id = pio.patient_id
     WHERE pio.status = 'ordered'
     ORDER BY pio.ordered_at`
  );
  res.json(rows.map(r => ({
    id: r.id, patientId: r.patient_id, patientName: r.patient_name,
    itemCode: r.item_code, description: r.description, qty: r.qty,
    orderedBy: r.ordered_by, orderedAt: r.ordered_at
  })));
});

// Items OT has handed back unused, still awaiting the store's physical
// pickup/restock acknowledgment — otherwise a "returned" item just
// disappears from view with no trace that it needs to come back to stock.
router.get('/returns', async (req, res) => {
  const { rows } = await pool.query(
    `SELECT pio.*, p.name AS patient_name, p.id AS patient_id
     FROM patient_item_orders pio
     JOIN patients p ON p.id = pio.patient_id
     WHERE pio.status = 'returned' AND pio.return_acknowledged_at IS NULL
     ORDER BY pio.ordered_at`
  );
  res.json(rows.map(r => ({
    id: r.id, patientId: r.patient_id, patientName: r.patient_name,
    itemCode: r.item_code, description: r.description, qty: r.qty,
    orderedBy: r.ordered_by, orderedAt: r.ordered_at
  })));
});

module.exports = router;
