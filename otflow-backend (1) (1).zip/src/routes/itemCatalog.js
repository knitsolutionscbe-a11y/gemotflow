const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { uid, catalogRowToApi } = require('../utils/helpers');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM item_catalog ORDER BY s_no, description');
  res.json(rows.map(catalogRowToApi));
});

router.post('/', requireRole('superadmin', 'admin'), async (req, res) => {
  const { sNo, itemCode, description, uom, itemGroup, itemType } = req.body || {};
  if (!itemCode || !description) return res.status(400).json({ error: 'Item Code and Item Description are required' });
  const { rows: existing } = await pool.query('SELECT id FROM item_catalog WHERE lower(item_code)=lower($1)', [itemCode]);
  if (existing.length) return res.status(409).json({ error: 'That Item Code already exists' });
  const id = uid('ci');
  await pool.query(
    `INSERT INTO item_catalog (id, s_no, item_code, description, uom, item_group, item_type) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [id, sNo || '', itemCode, description, uom || '', itemGroup || '', itemType || '']
  );
  res.status(201).json({ id, sNo, itemCode, description, uom, itemGroup, itemType });
});

// Bulk import (used by CSV upload) — skips codes that already exist.
router.post('/bulk', requireRole('superadmin', 'admin'), async (req, res) => {
  const { rows } = req.body || {};
  if (!Array.isArray(rows)) return res.status(400).json({ error: 'rows array required' });
  let added = 0, skipped = 0;
  for (const r of rows) {
    if (!r.itemCode || !r.description) { skipped++; continue; }
    const { rows: existing } = await pool.query('SELECT id FROM item_catalog WHERE lower(item_code)=lower($1)', [r.itemCode]);
    if (existing.length) { skipped++; continue; }
    await pool.query(
      `INSERT INTO item_catalog (id, s_no, item_code, description, uom, item_group, item_type) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [uid('ci'), r.sNo || '', r.itemCode, r.description, r.uom || '', r.itemGroup || '', r.itemType || '']
    );
    added++;
  }
  res.status(201).json({ added, skipped });
});

router.put('/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  const { sNo, itemCode, description, uom, itemGroup, itemType } = req.body || {};
  if (!itemCode || !description) return res.status(400).json({ error: 'Item Code and Item Description are required' });
  await pool.query(
    `UPDATE item_catalog SET s_no=$1, item_code=$2, description=$3, uom=$4, item_group=$5, item_type=$6 WHERE id=$7`,
    [sNo || '', itemCode, description, uom || '', itemGroup || '', itemType || '', req.params.id]
  );
  res.json({ id: req.params.id, sNo, itemCode, description, uom, itemGroup, itemType });
});

router.delete('/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  await pool.query('DELETE FROM item_catalog WHERE id=$1', [req.params.id]);
  res.status(204).end();
});

module.exports = router;
