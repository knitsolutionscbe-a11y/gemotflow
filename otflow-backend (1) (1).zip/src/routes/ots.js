const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { uid } = require('../utils/helpers');

const router = express.Router();
router.use(requireAuth);

function toApi(o) { return { id: o.id, name: o.name, floor: o.floor, status: o.status, patientId: o.patient_id }; }

router.get('/', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM ots ORDER BY name');
  res.json(rows.map(toApi));
});

router.post('/', requireRole('superadmin', 'admin'), async (req, res) => {
  const { name, floor } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Theatre name is required' });
  const id = uid('ot');
  await pool.query("INSERT INTO ots (id, name, floor, status) VALUES ($1,$2,$3,'vacant')", [id, name, floor || null]);
  res.status(201).json({ id, name, floor, status: 'vacant', patientId: null });
});

router.put('/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  const { name, floor } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Theatre name is required' });
  await pool.query('UPDATE ots SET name=$1, floor=$2 WHERE id=$3', [name, floor || null, req.params.id]);
  res.json({ id: req.params.id, name, floor });
});

router.delete('/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  await pool.query('DELETE FROM ots WHERE id=$1', [req.params.id]);
  res.status(204).end();
});

router.patch('/:id/mark-ready', async (req, res) => {
  const u = req.user;
  const okDept = u.role==='superadmin' || u.role==='admin' || u.department==='all' || u.department==='ot';
  if (!okDept) return res.status(403).json({ error: 'Theatre department staff only' });
  await pool.query("UPDATE ots SET status='vacant', patient_id=NULL WHERE id=$1", [req.params.id]);
  const { rows } = await pool.query('SELECT * FROM ots WHERE id=$1', [req.params.id]);
  res.json(toApi(rows[0]));
});

module.exports = router;
