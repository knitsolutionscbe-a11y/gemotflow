const express = require('express');
const pool = require('../db');
const { requireAuth, requireDept, requireRole, hasWardScope, hasOtScope } = require('../middleware/auth');
const { uid, patientRowToApi, itemOrderRowToApi } = require('../utils/helpers');

const router = express.Router();
router.use(requireAuth);

async function logActivity(client, patientId, text, byUser) {
  const { rows } = await client.query('SELECT activity FROM patients WHERE id=$1', [patientId]);
  const activity = rows[0]?.activity || [];
  activity.push({ text, at: new Date().toISOString(), by: byUser });
  await client.query('UPDATE patients SET activity=$1 WHERE id=$2', [JSON.stringify(activity), patientId]);
}

async function auditEntry(client, { byUser, byUserId, byRole, patientId, patientName, action, reason }) {
  await client.query(
    `INSERT INTO audit_log (id, by_user, by_user_id, by_role, patient_id, patient_name, action, reason)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [uid('al'), byUser, byUserId, byRole, patientId, patientName, action, reason || '']
  );
}

async function getPatient(id) {
  const { rows } = await pool.query('SELECT * FROM patients WHERE id=$1', [id]);
  const p = rows[0];
  if (!p) return null;
  const { rows: orders } = await pool.query('SELECT * FROM patient_item_orders WHERE patient_id=$1 ORDER BY ordered_at', [id]);
  p.itemOrders = orders.map(itemOrderRowToApi);
  return p;
}

// ---------- LIST / GET ----------
router.get('/', async (req, res) => {
  const { status, q } = req.query;
  const clauses = [];
  const params = [];
  if (status) { params.push(status); clauses.push(`status = $${params.length}`); }
  if (q) { params.push(`%${q.toLowerCase()}%`); clauses.push(`(lower(name) LIKE $${params.length} OR lower(uhid) LIKE $${params.length} OR lower(bed_label) LIKE $${params.length})`); }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  const { rows } = await pool.query(`SELECT * FROM patients ${where} ORDER BY updated_at DESC`, params);
  const ids = rows.map(r => r.id);
  let ordersByPatient = {};
  if (ids.length) {
    const { rows: orders } = await pool.query('SELECT * FROM patient_item_orders WHERE patient_id = ANY($1) ORDER BY ordered_at', [ids]);
    orders.forEach(o => { (ordersByPatient[o.patient_id] = ordersByPatient[o.patient_id] || []).push(itemOrderRowToApi(o)); });
  }
  res.json(rows.map(r => patientRowToApi(Object.assign(r, { itemOrders: ordersByPatient[r.id] || [] }))));
});

router.get('/:id', async (req, res) => {
  const p = await getPatient(req.params.id);
  if (!p) return res.status(404).json({ error: 'Patient not found' });
  res.json(patientRowToApi(p));
});

// ---------- ADMIT (ward) ----------
router.post('/', requireDept('ward'), async (req, res) => {
  const { name, uhid, wardId, roomId, bedLabel, age, sex, surgeryType, wardIn, bookingId, surgeon } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Patient name is required' });
  if (wardId && !hasWardScope(req.user, wardId)) return res.status(403).json({ error: 'That ward is outside your assigned scope' });
  const id = uid('pt');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `INSERT INTO patients (id, name, uhid, ward_id, room_id, bed_label, age, sex, surgery_type, surgeon,
         status, booking_id, booking_no, ward_in, activity)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'ward',$11,$12,$13,$14)`,
      [id, name, uhid || null, wardId || null, roomId || null, bedLabel || null, age || null, sex || null,
       surgeryType || null, surgeon || null, bookingId || null,
       req.body.bookingNo || null, wardIn || new Date().toISOString(),
       JSON.stringify([{ text: `Admitted to ward by ${req.user.full_name}`, at: new Date().toISOString(), by: req.user.full_name }])]
    );
    if (bookingId) {
      await client.query("UPDATE bookings SET status='admitted', linked_patient_id=$1 WHERE id=$2", [id, bookingId]);
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK'); throw err;
  } finally { client.release(); }
  res.status(201).json(patientRowToApi(await getPatient(id)));
});

// ---------- SEND TO PRE-OP (ward) ----------
router.post('/:id/send-preop', requireDept('ward'), async (req, res) => {
  const { preopBayId, sentAt } = req.body || {};
  const bay = (await pool.query('SELECT * FROM preop_bays WHERE id=$1', [preopBayId])).rows[0];
  if (!bay || bay.status !== 'vacant') return res.status(409).json({ error: 'That pre-op bay is not vacant' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE patients SET status='awaiting_preop_receive', pending_preop_id=$1, sent_to_preop_at=$2, updated_at=now() WHERE id=$3`,
      [preopBayId, sentAt || new Date().toISOString(), req.params.id]
    );
    await client.query("UPDATE preop_bays SET status='reserved', patient_id=$1 WHERE id=$2", [req.params.id, preopBayId]);
    await logActivity(client, req.params.id, `Sent to ${bay.name} by ${req.user.full_name}`, req.user.full_name);
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- RECEIVE INTO PRE-OP (preop) ----------
router.post('/:id/receive-preop', requireDept('preop'), async (req, res) => {
  const { receivedAt } = req.body || {};
  const p = await getPatient(req.params.id);
  if (!p || !p.pending_preop_id) return res.status(409).json({ error: 'This patient is not pending pre-op receipt' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE patients SET status='preop', assigned_preop_id=$1, pending_preop_id=NULL, preop_in=$2, updated_at=now() WHERE id=$3`,
      [p.pending_preop_id, receivedAt || new Date().toISOString(), req.params.id]
    );
    await client.query("UPDATE preop_bays SET status='occupied' WHERE id=$1", [p.pending_preop_id]);
    await logActivity(client, req.params.id, `Received into pre-op by ${req.user.full_name}`, req.user.full_name);
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- SEND TO OT (preop) ----------
router.post('/:id/send-ot', requireDept('preop'), async (req, res) => {
  const { otId, surgeon, procedure, sentAt } = req.body || {};
  const ot = (await pool.query('SELECT * FROM ots WHERE id=$1', [otId])).rows[0];
  if (!ot || ot.status !== 'vacant') return res.status(409).json({ error: 'That theatre is not vacant' });
  const p = await getPatient(req.params.id);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE patients SET status='awaiting_ot_receive', pending_ot_id=$1, sent_to_ot_at=$2,
         surgeon=COALESCE($3, surgeon), surgery_type=COALESCE($4, surgery_type),
         assigned_preop_id=NULL, updated_at=now() WHERE id=$5`,
      [otId, sentAt || new Date().toISOString(), surgeon || null, procedure || null, req.params.id]
    );
    await client.query("UPDATE ots SET status='reserved', patient_id=$1 WHERE id=$2", [req.params.id, otId]);
    if (p.assigned_preop_id) {
      await client.query("UPDATE preop_bays SET status='vacant', patient_id=NULL WHERE id=$1 AND patient_id=$2", [p.assigned_preop_id, req.params.id]);
    }
    await logActivity(client, req.params.id, `Sent to ${ot.name} by ${req.user.full_name}`, req.user.full_name);
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- RECEIVE INTO THEATRE (ot) ----------
router.post('/:id/receive-ot', requireDept('ot'), async (req, res) => {
  const { anesthesiaType, anesthetist, receivedAt } = req.body || {};
  const p = await getPatient(req.params.id);
  if (!p || !p.pending_ot_id) return res.status(409).json({ error: 'This patient is not pending theatre receipt' });
  if (!hasOtScope(req.user, p.pending_ot_id)) return res.status(403).json({ error: 'That theatre is outside your assigned scope' });
  const ot = (await pool.query('SELECT * FROM ots WHERE id=$1', [p.pending_ot_id])).rows[0];
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE patients SET status='ot', assigned_ot_id=$1, ot_name_snapshot=$2, pending_ot_id=NULL,
         ot_in=$3, anesthesia_type=$4, anesthetist=$5, updated_at=now() WHERE id=$6`,
      [p.pending_ot_id, ot.name, receivedAt || new Date().toISOString(), anesthesiaType || null, anesthetist || null, req.params.id]
    );
    await client.query("UPDATE ots SET status='occupied' WHERE id=$1", [p.pending_ot_id]);
    if (anesthetist) {
      await client.query(
        "INSERT INTO masters (id, type, value) VALUES ($1,'anesthetist',$2) ON CONFLICT (type,value) DO NOTHING",
        [uid('m'), anesthetist]
      );
    }
    await logActivity(client, req.params.id, `Received into ${ot.name} by ${req.user.full_name}`, req.user.full_name);
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- LOG OT TIMESTAMP STEP (ot) ----------
const OT_STEP_COLUMNS = {
  otIn: 'ot_in', anesStart: 'anes_start', surgStart: 'surg_start',
  surgEnd: 'surg_end', anesEnd: 'anes_end', otOut: 'ot_out'
};
router.post('/:id/log-step', requireDept('ot'), async (req, res) => {
  const { step, time } = req.body || {};
  const col = OT_STEP_COLUMNS[step];
  if (!col) return res.status(400).json({ error: 'Unknown step' });
  const p = await getPatient(req.params.id);
  if (!p) return res.status(404).json({ error: 'Patient not found' });
  if (!hasOtScope(req.user, p.assigned_ot_id)) return res.status(403).json({ error: 'That theatre is outside your assigned scope' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(`UPDATE patients SET ${col}=$1, updated_at=now() WHERE id=$2`, [time || new Date().toISOString(), req.params.id]);
    await logActivity(client, req.params.id, `${step} logged by ${req.user.full_name}`, req.user.full_name);
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- DRUGS / OT ITEMS ----------
router.patch('/:id/case-items', requireDept('ot'), async (req, res) => {
  const { drugsUsed, otItemsUsedList } = req.body || {};
  const p = await getPatient(req.params.id);
  if (!p) return res.status(404).json({ error: 'Patient not found' });
  if (!hasOtScope(req.user, p.assigned_ot_id)) return res.status(403).json({ error: 'That theatre is outside your assigned scope' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    if (drugsUsed) await client.query('UPDATE patients SET drugs_used=$1, updated_at=now() WHERE id=$2', [JSON.stringify(drugsUsed), req.params.id]);
    if (otItemsUsedList) await client.query('UPDATE patients SET ot_items_used=$1, updated_at=now() WHERE id=$2', [JSON.stringify(otItemsUsedList), req.params.id]);
    for (const d of (drugsUsed || [])) {
      await client.query("INSERT INTO masters (id, type, value) VALUES ($1,'drug',$2) ON CONFLICT (type,value) DO NOTHING", [uid('m'), d]);
    }
    for (const it of (otItemsUsedList || [])) {
      await client.query("INSERT INTO masters (id, type, value) VALUES ($1,'ot_item',$2) ON CONFLICT (type,value) DO NOTHING", [uid('m'), it]);
    }
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- MOVE TO RECOVERY (ot) ----------
router.post('/:id/move-recovery', requireDept('ot'), async (req, res) => {
  const { bedId, recoveryInAt } = req.body || {};
  const bed = (await pool.query('SELECT * FROM beds WHERE id=$1', [bedId])).rows[0];
  if (!bed || bed.status !== 'vacant') return res.status(409).json({ error: 'That recovery bed is not vacant' });
  const p = await getPatient(req.params.id);
  if (!hasOtScope(req.user, p.assigned_ot_id)) return res.status(403).json({ error: 'That theatre is outside your assigned scope' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE patients SET status='recovery', recovery_in=$1, updated_at=now() WHERE id=$2`,
      [recoveryInAt || new Date().toISOString(), req.params.id]
    );
    await client.query("UPDATE beds SET status='occupied', patient_id=$1 WHERE id=$2", [req.params.id, bedId]);
    if (p.assigned_ot_id) {
      await client.query("UPDATE ots SET status='cleaning', patient_id=NULL WHERE id=$1 AND patient_id=$2", [p.assigned_ot_id, req.params.id]);
    }
    await logActivity(client, req.params.id, `Moved to ${bed.name} by ${req.user.full_name}`, req.user.full_name);
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

router.patch('/:id/recovery-notes', requireDept('recovery'), async (req, res) => {
  await pool.query('UPDATE patients SET recovery_notes=$1, updated_at=now() WHERE id=$2', [req.body?.recoveryNotes || '', req.params.id]);
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

router.post('/:id/vitals/preop', requireDept('preop'), async (req, res) => {
  const { bp, spo2 } = req.body || {};
  if (!bp && !spo2) return res.status(400).json({ error: 'Provide BP and/or SpO2' });
  const p = await getPatient(req.params.id);
  const log = p.preop_vitals_log || [];
  log.push({ at: new Date().toISOString(), bp: bp || '', spo2: spo2 || '', by: req.user.full_name });
  await pool.query('UPDATE patients SET preop_vitals_log=$1, updated_at=now() WHERE id=$2', [JSON.stringify(log), req.params.id]);
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

router.post('/:id/vitals/recovery', requireDept('recovery'), async (req, res) => {
  const { bp, spo2 } = req.body || {};
  if (!bp && !spo2) return res.status(400).json({ error: 'Provide BP and/or SpO2' });
  const p = await getPatient(req.params.id);
  const log = p.recovery_vitals_log || [];
  log.push({ at: new Date().toISOString(), bp: bp || '', spo2: spo2 || '', by: req.user.full_name });
  await pool.query('UPDATE patients SET recovery_vitals_log=$1, updated_at=now() WHERE id=$2', [JSON.stringify(log), req.params.id]);
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- SEND TO WARD (recovery) ----------
router.post('/:id/send-ward', requireDept('recovery'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE patients SET status='awaiting_ward_receive', sent_to_ward_at=$1, updated_at=now() WHERE id=$2`,
      [req.body?.sentAt || new Date().toISOString(), req.params.id]
    );
    await logActivity(client, req.params.id, `Sent from recovery towards ward`, req.user.full_name);
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- RECEIVE ON WARD (ward) ----------
router.post('/:id/receive-ward', requireDept('ward'), async (req, res) => {
  const { wardId, roomId, receivedAt } = req.body || {};
  const p = await getPatient(req.params.id);
  const finalWardId = wardId || p.ward_id;
  if (finalWardId && !hasWardScope(req.user, finalWardId)) return res.status(403).json({ error: 'That ward is outside your assigned scope' });
  const bed = (await pool.query('SELECT * FROM beds WHERE patient_id=$1', [req.params.id])).rows[0];
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE patients SET status='returned', ward_id=COALESCE($1, ward_id), room_id=COALESCE($2, room_id),
         ward_return=$3, updated_at=now() WHERE id=$4`,
      [wardId || null, roomId || null, receivedAt || new Date().toISOString(), req.params.id]
    );
    if (bed) await client.query("UPDATE beds SET status='vacant', patient_id=NULL WHERE id=$1", [bed.id]);
    await logActivity(client, req.params.id, `Received on ward by ${req.user.full_name}`, req.user.full_name);
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- SUPER ADMIN: CANCEL CASE ----------
router.post('/:id/cancel-case', requireRole('superadmin'), async (req, res) => {
  const { reason } = req.body || {};
  if (!reason) return res.status(400).json({ error: 'A reason is required' });
  const p = await getPatient(req.params.id);
  if (!p) return res.status(404).json({ error: 'Patient not found' });
  const fromStatus = p.status;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    if (p.pending_preop_id || p.assigned_preop_id) {
      const bayId = p.assigned_preop_id || p.pending_preop_id;
      await client.query("UPDATE preop_bays SET status='vacant', patient_id=NULL WHERE id=$1 AND patient_id=$2", [bayId, p.id]);
    }
    if (p.pending_ot_id || p.assigned_ot_id) {
      const otId = p.assigned_ot_id || p.pending_ot_id;
      const newOtStatus = p.assigned_ot_id ? 'cleaning' : 'vacant';
      await client.query("UPDATE ots SET status=$1, patient_id=NULL WHERE id=$2 AND patient_id=$3", [newOtStatus, otId, p.id]);
    }
    await client.query("UPDATE beds SET status='vacant', patient_id=NULL WHERE patient_id=$1", [p.id]);

    await client.query(
      `UPDATE patients SET status='ward', pending_preop_id=NULL, assigned_preop_id=NULL,
         pending_ot_id=NULL, assigned_ot_id=NULL, ward_return=now(),
         case_cancelled=true, cancel_reason=$1, cancelled_at=now(), cancelled_by=$2, updated_at=now()
       WHERE id=$3`,
      [reason, req.user.full_name, p.id]
    );
    if (p.booking_id) await client.query("UPDATE bookings SET status='cancelled' WHERE id=$1", [p.booking_id]);
    await logActivity(client, p.id, `CORRECTED BY SUPER ADMIN: Case cancelled from ${fromStatus} — reason: ${reason}`, req.user.full_name);
    await auditEntry(client, {
      byUser: req.user.full_name, byUserId: req.user.id, byRole: req.user.role,
      patientId: p.id, patientName: p.name, action: `Case cancelled from ${fromStatus} → sent to ward`, reason
    });
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- SUPER ADMIN: REVERSE / CORRECT ----------
router.post('/:id/reverse', requireRole('superadmin'), async (req, res) => {
  const { action, reason, bedId } = req.body || {};
  if (!reason) return res.status(400).json({ error: 'A reason is required' });
  const p = await getPatient(req.params.id);
  if (!p) return res.status(404).json({ error: 'Patient not found' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    let summary = '';

    if (action === 'awaitingPreopReceiveToWard') {
      if (p.pending_preop_id) await client.query("UPDATE preop_bays SET status='vacant', patient_id=NULL WHERE id=$1 AND patient_id=$2", [p.pending_preop_id, p.id]);
      await client.query("UPDATE patients SET status='ward', pending_preop_id=NULL, sent_to_preop_at=NULL, updated_at=now() WHERE id=$1", [p.id]);
      summary = 'Sent-to-pre-op → Ward';

    } else if (action === 'preopToPendingReceive') {
      if (!p.assigned_preop_id) { await client.query('ROLLBACK'); client.release(); return res.status(409).json({ error: 'This patient is not currently occupying a pre-op bay' }); }
      await client.query("UPDATE preop_bays SET status='reserved' WHERE id=$1", [p.assigned_preop_id]);
      await client.query("UPDATE patients SET status='awaiting_preop_receive', pending_preop_id=$1, assigned_preop_id=NULL, preop_in=NULL, updated_at=now() WHERE id=$2", [p.assigned_preop_id, p.id]);
      summary = 'In pre-op → Pending pre-op receipt (un-received)';

    } else if (action === 'preopToWard') {
      const bayId = p.assigned_preop_id || p.pending_preop_id;
      if (bayId) await client.query("UPDATE preop_bays SET status='vacant', patient_id=NULL WHERE id=$1 AND patient_id=$2", [bayId, p.id]);
      await client.query("UPDATE patients SET status='ward', pending_preop_id=NULL, assigned_preop_id=NULL, sent_to_preop_at=NULL, preop_in=NULL, updated_at=now() WHERE id=$1", [p.id]);
      summary = 'In pre-op → Ward';

    } else if (action === 'awaitingOtReceiveToPreop') {
      if (p.pending_ot_id) await client.query("UPDATE ots SET status='vacant', patient_id=NULL WHERE id=$1 AND patient_id=$2", [p.pending_ot_id, p.id]);
      if (p.preop_in) {
        const { rows: vacantBays } = await client.query("SELECT id, name FROM preop_bays WHERE status='vacant' LIMIT 1");
        if (vacantBays.length) {
          const bay = vacantBays[0];
          await client.query("UPDATE preop_bays SET status='occupied', patient_id=$1 WHERE id=$2", [p.id, bay.id]);
          await client.query("UPDATE patients SET status='preop', assigned_preop_id=$1, pending_ot_id=NULL, sent_to_ot_at=NULL, updated_at=now() WHERE id=$2", [bay.id, p.id]);
          summary = `Sent-to-theatre → Pre-Op (${bay.name})`;
        } else {
          await client.query("UPDATE patients SET status='ward', pending_ot_id=NULL, sent_to_ot_at=NULL, updated_at=now() WHERE id=$1", [p.id]);
          summary = 'Sent-to-theatre → Ward (no pre-op bay free to restore into)';
        }
      } else {
        await client.query("UPDATE patients SET status='ward', pending_ot_id=NULL, sent_to_ot_at=NULL, updated_at=now() WHERE id=$1", [p.id]);
        summary = 'Sent-to-theatre → Ward';
      }

    } else if (action === 'otToPendingReceive') {
      if (!p.assigned_ot_id) { await client.query('ROLLBACK'); client.release(); return res.status(409).json({ error: 'This theatre is no longer holding this patient' }); }
      await client.query("UPDATE ots SET status='reserved' WHERE id=$1", [p.assigned_ot_id]);
      await client.query(
        `UPDATE patients SET status='awaiting_ot_receive', pending_ot_id=$1, assigned_ot_id=NULL, ot_name_snapshot=NULL,
           ot_in=NULL, anes_start=NULL, surg_start=NULL, surg_end=NULL, anes_end=NULL, ot_out=NULL,
           anesthesia_type=NULL, anesthetist=NULL, updated_at=now() WHERE id=$2`,
        [p.assigned_ot_id, p.id]
      );
      summary = 'In theatre → Pending theatre receipt (un-received)';

    } else if (action === 'otToWard') {
      const otId = p.assigned_ot_id || p.pending_ot_id;
      if (otId) await client.query("UPDATE ots SET status='vacant', patient_id=NULL WHERE id=$1 AND patient_id=$2", [otId, p.id]);
      await client.query(
        `UPDATE patients SET status='ward', pending_preop_id=NULL, assigned_preop_id=NULL, pending_ot_id=NULL, assigned_ot_id=NULL,
           ot_name_snapshot=NULL, sent_to_preop_at=NULL, preop_in=NULL, sent_to_ot_at=NULL, ot_in=NULL,
           anes_start=NULL, surg_start=NULL, surg_end=NULL, anes_end=NULL, ot_out=NULL,
           anesthesia_type=NULL, anesthetist=NULL, surgeon=NULL, updated_at=now() WHERE id=$1`,
        [p.id]
      );
      summary = 'In theatre → Ward (full rollback of theatre case)';

    } else if (action === 'recoveryToOt') {
      if (!p.assigned_ot_id) { await client.query('ROLLBACK'); client.release(); return res.status(409).json({ error: 'Original theatre no longer exists — cannot auto-reverse' }); }
      const ot = (await client.query('SELECT * FROM ots WHERE id=$1', [p.assigned_ot_id])).rows[0];
      if (ot.patient_id && ot.patient_id !== p.id) { await client.query('ROLLBACK'); client.release(); return res.status(409).json({ error: 'This theatre has since been assigned to another patient' }); }
      await client.query("UPDATE ots SET status='occupied', patient_id=$1 WHERE id=$2", [p.id, p.assigned_ot_id]);
      await client.query("UPDATE beds SET status='vacant', patient_id=NULL WHERE patient_id=$1", [p.id]);
      await client.query("UPDATE patients SET status='ot', recovery_in=NULL, ot_out=NULL, updated_at=now() WHERE id=$1", [p.id]);
      summary = 'Recovery → In theatre (undo move to recovery)';

    } else if (action === 'awaitingWardToRecovery') {
      await client.query("UPDATE patients SET status='recovery', sent_to_ward_at=NULL, updated_at=now() WHERE id=$1", [p.id]);
      summary = 'Sent-to-ward → Recovery (cancelled ward send)';

    } else if (action === 'returnedToRecovery') {
      if (!bedId) { await client.query('ROLLBACK'); client.release(); return res.status(400).json({ error: 'Choose a recovery bed' }); }
      const bed = (await client.query('SELECT * FROM beds WHERE id=$1', [bedId])).rows[0];
      if (!bed || bed.status !== 'vacant') { await client.query('ROLLBACK'); client.release(); return res.status(409).json({ error: 'Choose a vacant recovery bed' }); }
      await client.query("UPDATE beds SET status='occupied', patient_id=$1 WHERE id=$2", [p.id, bedId]);
      await client.query(
        `UPDATE patients SET status='recovery', ward_return=NULL, sent_to_ward_at=NULL,
           recovery_in=COALESCE(recovery_in, now()), updated_at=now() WHERE id=$1`,
        [p.id]
      );
      summary = 'Discharged to ward → Recovery (undo ward discharge)';

    } else {
      await client.query('ROLLBACK'); client.release();
      return res.status(400).json({ error: 'Unknown reversal action' });
    }

    await logActivity(client, p.id, `CORRECTED BY SUPER ADMIN: ${summary} — reason: ${reason}`, req.user.full_name);
    await auditEntry(client, {
      byUser: req.user.full_name, byUserId: req.user.id, byRole: req.user.role,
      patientId: p.id, patientName: p.name, action: summary, reason
    });
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK'); client.release(); throw err;
  }
  client.release();
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- PRE-OP: EMERGENCY ADMISSION (bypasses ward) ----------
const PREOP_CAPACITY = 7;
async function preopPatientCount() {
  const { rows } = await pool.query("SELECT COUNT(*)::int AS c FROM patients WHERE status IN ('awaiting_preop_receive','preop')");
  return rows[0].c;
}
router.post('/emergency-admit', requireDept('preop'), async (req, res) => {
  const { name, uhid, age, sex, procedure, bayId, reason, admitTime, bookingId } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Patient name is required' });
  if (!bayId) return res.status(400).json({ error: 'A pre-op bay is required' });
  if (!reason) return res.status(400).json({ error: 'A reason is required for an emergency admission' });
  if ((await preopPatientCount()) >= PREOP_CAPACITY) return res.status(409).json({ error: `Pre-Op is at its maximum capacity of ${PREOP_CAPACITY} patients` });
  const bay = (await pool.query('SELECT * FROM preop_bays WHERE id=$1', [bayId])).rows[0];
  if (!bay || bay.status !== 'vacant') return res.status(409).json({ error: 'That pre-op bay is not vacant' });
  const id = uid('pt');
  const time = admitTime || new Date().toISOString();
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `INSERT INTO patients (id, name, uhid, age, sex, surgery_type, status, assigned_preop_id,
         emergency_admission, emergency_reason, emergency_admitted_by, emergency_admitted_at,
         booking_id, ward_in, sent_to_preop_at, preop_in, activity)
       VALUES ($1,$2,$3,$4,$5,$6,'preop',$7,true,$8,$9,now(),$10,$11,$11,$11,$12)`,
      [id, name, uhid || null, age || null, sex || null, procedure || null, bayId, reason, req.user.full_name,
       bookingId || null, time,
       JSON.stringify([{ text: `EMERGENCY ADMISSION directly to ${bay.name} by ${req.user.full_name} (ward admission bypassed) — reason: ${reason}`, at: new Date().toISOString(), by: req.user.full_name }])]
    );
    await client.query("UPDATE preop_bays SET status='occupied', patient_id=$1 WHERE id=$2", [id, bayId]);
    if (bookingId) await client.query("UPDATE bookings SET status='admitted', linked_patient_id=$1 WHERE id=$2", [id, bookingId]);
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.status(201).json(patientRowToApi(await getPatient(id)));
});

// Fast-track a patient who is already an existing ward record straight into
// Pre-Op, skipping the normal Send/Receive handshake — for an emergency where
// the patient is already known to the system, not brand new.
router.post('/:id/fast-track-preop', requireDept('preop'), async (req, res) => {
  const { bayId, reason, admitTime, procedure } = req.body || {};
  if (!bayId) return res.status(400).json({ error: 'A pre-op bay is required' });
  if (!reason) return res.status(400).json({ error: 'A reason is required for an emergency fast-track' });
  const p = await getPatient(req.params.id);
  if (!p || p.status !== 'ward') return res.status(409).json({ error: 'That patient is no longer on the ward' });
  if ((await preopPatientCount()) >= PREOP_CAPACITY) return res.status(409).json({ error: `Pre-Op is at its maximum capacity of ${PREOP_CAPACITY} patients` });
  const bay = (await pool.query('SELECT * FROM preop_bays WHERE id=$1', [bayId])).rows[0];
  if (!bay || bay.status !== 'vacant') return res.status(409).json({ error: 'That pre-op bay is not vacant' });
  const time = admitTime || new Date().toISOString();
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE patients SET status='preop', assigned_preop_id=$1, surgery_type=COALESCE($2, surgery_type),
         sent_to_preop_at=$3, preop_in=$3,
         emergency_admission=true, emergency_reason=$4, emergency_admitted_by=$5, emergency_admitted_at=now(),
         updated_at=now() WHERE id=$6`,
      [bayId, procedure || null, time, reason, req.user.full_name, req.params.id]
    );
    await client.query("UPDATE preop_bays SET status='occupied', patient_id=$1 WHERE id=$2", [req.params.id, bayId]);
    await logActivity(client, req.params.id, `EMERGENCY FAST-TRACK: existing ward patient sent directly into ${bay.name} by ${req.user.full_name} (normal Send-to-Pre-Op step bypassed) — reason: ${reason}`, req.user.full_name);
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// ---------- OT STORE: ORDER -> ISSUE -> RECEIVE -> USE/RETURN -> BILL ----------
async function getItemOrder(patientId, orderId) {
  const { rows } = await pool.query('SELECT * FROM patient_item_orders WHERE id=$1 AND patient_id=$2', [orderId, patientId]);
  return rows[0];
}

// Order an item from the store. Not tied to a specific theatre — ordering can
// happen before a patient ever reaches Pre-Op or Theatre, so this checks only
// general "Theatre department" membership, not a specific OT's scope.
router.post('/:id/item-orders', requireDept('ot'), async (req, res) => {
  const { catalogId, qty } = req.body || {};
  if (!catalogId) return res.status(400).json({ error: 'catalogId is required' });
  const { rows: catRows } = await pool.query('SELECT * FROM item_catalog WHERE id=$1', [catalogId]);
  const item = catRows[0];
  if (!item) return res.status(404).json({ error: 'Catalog item not found' });
  const q = Number(qty) || 1;
  // Merge into an existing still-"ordered" line for the same item rather than duplicating.
  const { rows: existingRows } = await pool.query(
    "SELECT * FROM patient_item_orders WHERE patient_id=$1 AND catalog_id=$2 AND status='ordered'",
    [req.params.id, catalogId]
  );
  if (existingRows.length) {
    await pool.query('UPDATE patient_item_orders SET qty=$1 WHERE id=$2', [existingRows[0].qty + q, existingRows[0].id]);
  } else {
    await pool.query(
      `INSERT INTO patient_item_orders (id, patient_id, catalog_id, item_code, description, uom, item_group, item_type, qty, status, ordered_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'ordered',$10)`,
      [uid('io'), req.params.id, item.id, item.item_code, item.description, item.uom, item.item_group, item.item_type, q, req.user.full_name]
    );
  }
  res.status(201).json(patientRowToApi(await getPatient(req.params.id)));
});

// Add every item in a surgery package to this patient's order in one go.
router.post('/:id/item-orders/from-package', requireDept('ot'), async (req, res) => {
  const { packageId } = req.body || {};
  const { rows: itemRows } = await pool.query(
    `SELECT spi.qty, ic.* FROM surgery_package_items spi JOIN item_catalog ic ON ic.id = spi.catalog_id WHERE spi.package_id=$1`,
    [packageId]
  );
  if (!itemRows.length) return res.status(404).json({ error: 'Package not found or empty' });
  for (const item of itemRows) {
    const { rows: existingRows } = await pool.query(
      "SELECT * FROM patient_item_orders WHERE patient_id=$1 AND catalog_id=$2 AND status='ordered'",
      [req.params.id, item.id]
    );
    if (existingRows.length) {
      await pool.query('UPDATE patient_item_orders SET qty=$1 WHERE id=$2', [existingRows[0].qty + item.qty, existingRows[0].id]);
    } else {
      await pool.query(
        `INSERT INTO patient_item_orders (id, patient_id, catalog_id, item_code, description, uom, item_group, item_type, qty, status, ordered_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'ordered',$10)`,
        [uid('io'), req.params.id, item.id, item.item_code, item.description, item.uom, item.item_group, item.item_type, item.qty, req.user.full_name]
      );
    }
  }
  res.status(201).json(patientRowToApi(await getPatient(req.params.id)));
});

router.patch('/:id/item-orders/:orderId/issue', requireDept('otstore'), async (req, res) => {
  const order = await getItemOrder(req.params.id, req.params.orderId);
  if (!order || order.status !== 'ordered') return res.status(409).json({ error: 'This item is not awaiting issue' });
  await pool.query("UPDATE patient_item_orders SET status='issued', issued_by=$1, issued_at=now() WHERE id=$2", [req.user.full_name, order.id]);
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

router.patch('/:id/item-orders/:orderId/receive', requireDept('ot'), async (req, res) => {
  const order = await getItemOrder(req.params.id, req.params.orderId);
  if (!order || order.status !== 'issued') return res.status(409).json({ error: 'This item has not been issued yet' });
  await pool.query("UPDATE patient_item_orders SET status='received', received_by=$1, received_at=now() WHERE id=$2", [req.user.full_name, order.id]);
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

router.patch('/:id/item-orders/:orderId/use', requireDept('ot'), async (req, res) => {
  const order = await getItemOrder(req.params.id, req.params.orderId);
  if (!order || order.status !== 'received') return res.status(409).json({ error: 'This item has not been received yet' });
  await pool.query("UPDATE patient_item_orders SET status='used', used_qty=qty WHERE id=$1", [order.id]);
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

router.patch('/:id/item-orders/:orderId/return', requireDept('ot'), async (req, res) => {
  const order = await getItemOrder(req.params.id, req.params.orderId);
  if (!order || order.status !== 'received') return res.status(409).json({ error: 'This item has not been received yet' });
  await pool.query("UPDATE patient_item_orders SET status='returned', used_qty=0, return_acknowledged_by=NULL, return_acknowledged_at=NULL WHERE id=$1", [order.id]);
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

// OT Store confirms they've physically taken the unused item back — the
// counterpart to the "issue" step, so returned items don't just vanish from
// view the moment OT marks them unused.
router.patch('/:id/item-orders/:orderId/acknowledge-return', requireDept('otstore'), async (req, res) => {
  const order = await getItemOrder(req.params.id, req.params.orderId);
  if (!order || order.status !== 'returned') return res.status(409).json({ error: 'This item is not marked as returned' });
  await pool.query("UPDATE patient_item_orders SET return_acknowledged_by=$1, return_acknowledged_at=now() WHERE id=$2", [req.user.full_name, order.id]);
  res.json(patientRowToApi(await getPatient(req.params.id)));
});

async function doBillingSubmission(patientId, user) {
  const { rows: usedOrders } = await pool.query("SELECT * FROM patient_item_orders WHERE patient_id=$1 AND status='used'", [patientId]);
  if (!usedOrders.length) return { status: 400, body: { error: 'No items marked Used are ready to bill' } };
  const p = await getPatient(patientId);
  const { rows: cfgRows } = await pool.query('SELECT * FROM integration_config WHERE id=1');
  const cfg = cfgRows[0];
  const payload = {
    patientId: p.id, patientName: p.name, uhid: p.uhid, bookingNo: p.booking_no,
    procedure: p.surgery_type, surgeon: p.surgeon,
    submittedBy: user.full_name, submittedAt: new Date().toISOString(),
    items: usedOrders.map(o => ({ itemCode: o.item_code, description: o.description, uom: o.uom, itemGroup: o.item_group, itemType: o.item_type, qty: o.used_qty }))
  };
  if (!cfg || !cfg.hms_api_url) {
    return { status: 400, body: { error: 'No HMS API endpoint configured. Ask your Super Admin to set it up under Billing Integration.' } };
  }
  try {
    const headers = { 'Content-Type': 'application/json' };
    if (cfg.hms_api_key) headers[cfg.hms_auth_header || 'Authorization'] = (cfg.hms_auth_scheme ? cfg.hms_auth_scheme + ' ' : '') + cfg.hms_api_key;
    const hmsRes = await fetch(cfg.hms_api_url, { method: 'POST', headers, body: JSON.stringify(payload) });
    if (hmsRes.ok) {
      await pool.query("UPDATE patient_item_orders SET status='billed', billed_at=now() WHERE patient_id=$1 AND status='used'", [patientId]);
      return { status: 200, body: { ok: true, patient: patientRowToApi(await getPatient(patientId)) } };
    }
    await pool.query("UPDATE patient_item_orders SET status='billing_failed' WHERE patient_id=$1 AND status='used'", [patientId]);
    return { status: 502, body: { error: `HMS responded with HTTP ${hmsRes.status}`, patient: patientRowToApi(await getPatient(patientId)) } };
  } catch (err) {
    await pool.query("UPDATE patient_item_orders SET status='billing_failed' WHERE patient_id=$1 AND status='used'", [patientId]);
    return { status: 502, body: { error: `Could not reach HMS: ${err.message}`, patient: patientRowToApi(await getPatient(patientId)) } };
  }
}

router.post('/:id/item-orders/submit-billing', requireDept('ot'), async (req, res) => {
  const result = await doBillingSubmission(req.params.id, req.user);
  res.status(result.status).json(result.body);
});

router.post('/:id/item-orders/retry-billing', requireDept('ot'), async (req, res) => {
  await pool.query("UPDATE patient_item_orders SET status='used' WHERE patient_id=$1 AND status='billing_failed'", [req.params.id]);
  const result = await doBillingSubmission(req.params.id, req.user);
  res.status(result.status).json(result.body);
});

module.exports = router;
