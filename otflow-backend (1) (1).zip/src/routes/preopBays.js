const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { uid } = require('../utils/helpers');

const router = express.Router();
router.use(requireAuth);

function toApi(b) { return { id: b.id, name: b.name, status: b.status, patientId: b.patient_id }; }

router.get('/', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM preop_bays ORDER BY name');
  res.json(rows.map(toApi));
});

router.post('/', requireRole('superadmin', 'admin'), async (req, res) => {
  const { name } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Bay name is required' });
  const id = uid('pp');
  await pool.query("INSERT INTO preop_bays (id, name, status) VALUES ($1,$2,'vacant')", [id, name]);
  res.status(201).json({ id, name, status: 'vacant', patientId: null });
});

router.put('/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  const { name } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Bay name is required' });
  await pool.query('UPDATE preop_bays SET name=$1 WHERE id=$2', [name, req.params.id]);
  res.json({ id: req.params.id, name });
});

router.delete('/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  await pool.query('DELETE FROM preop_bays WHERE id=$1', [req.params.id]);
  res.status(204).end();
});

module.exports = router;
