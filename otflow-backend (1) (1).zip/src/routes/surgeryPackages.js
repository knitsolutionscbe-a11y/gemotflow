const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { uid, catalogRowToApi } = require('../utils/helpers');

const router = express.Router();
router.use(requireAuth);

async function getPackageWithItems(pkgId) {
  const { rows: pkgRows } = await pool.query('SELECT * FROM surgery_packages WHERE id=$1', [pkgId]);
  const pkg = pkgRows[0];
  if (!pkg) return null;
  const { rows: itemRows } = await pool.query(
    `SELECT spi.qty, ic.* FROM surgery_package_items spi
     JOIN item_catalog ic ON ic.id = spi.catalog_id WHERE spi.package_id=$1`,
    [pkgId]
  );
  return {
    id: pkg.id,
    name: pkg.name,
    items: itemRows.map(r => ({ ...catalogRowToApi(r), catalogId: r.id, qty: r.qty }))
  };
}

router.get('/', async (req, res) => {
  const { rows } = await pool.query('SELECT id FROM surgery_packages ORDER BY name');
  const packages = await Promise.all(rows.map(r => getPackageWithItems(r.id)));
  res.json(packages);
});

router.post('/', requireRole('superadmin', 'admin'), async (req, res) => {
  const { name, items } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Package name is required' });
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'Add at least one item to the package' });
  const { rows: existing } = await pool.query('SELECT id FROM surgery_packages WHERE lower(name)=lower($1)', [name]);
  if (existing.length) return res.status(409).json({ error: 'A package with that name already exists' });
  const id = uid('pkg');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('INSERT INTO surgery_packages (id, name) VALUES ($1,$2)', [id, name]);
    for (const it of items) {
      await client.query(
        'INSERT INTO surgery_package_items (id, package_id, catalog_id, qty) VALUES ($1,$2,$3,$4)',
        [uid('pki'), id, it.catalogId, it.qty || 1]
      );
    }
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.status(201).json(await getPackageWithItems(id));
});

router.put('/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  const { name, items } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Package name is required' });
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'Add at least one item to the package' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('UPDATE surgery_packages SET name=$1 WHERE id=$2', [name, req.params.id]);
    await client.query('DELETE FROM surgery_package_items WHERE package_id=$1', [req.params.id]);
    for (const it of items) {
      await client.query(
        'INSERT INTO surgery_package_items (id, package_id, catalog_id, qty) VALUES ($1,$2,$3,$4)',
        [uid('pki'), req.params.id, it.catalogId, it.qty || 1]
      );
    }
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.json(await getPackageWithItems(req.params.id));
});

router.delete('/:id', requireRole('superadmin', 'admin'), async (req, res) => {
  await pool.query('DELETE FROM surgery_packages WHERE id=$1', [req.params.id]);
  res.status(204).end();
});

// Bulk import: rows of {packageName, itemCode, qty} — groups by package name,
// creating or adding to an existing package, matching items by Item Code.
router.post('/bulk', requireRole('superadmin', 'admin'), async (req, res) => {
  const { rows } = req.body || {};
  if (!Array.isArray(rows)) return res.status(400).json({ error: 'rows array required' });
  const missingCodes = new Set();
  const groups = {};
  for (const r of rows) {
    if (!r.packageName || !r.itemCode) continue;
    const { rows: catRows } = await pool.query('SELECT id FROM item_catalog WHERE lower(item_code)=lower($1)', [r.itemCode]);
    if (!catRows.length) { missingCodes.add(r.itemCode); continue; }
    const key = r.packageName.toLowerCase();
    if (!groups[key]) groups[key] = { name: r.packageName, items: [] };
    const existing = groups[key].items.find(it => it.catalogId === catRows[0].id);
    if (existing) existing.qty += Number(r.qty) || 1;
    else groups[key].items.push({ catalogId: catRows[0].id, qty: Number(r.qty) || 1 });
  }
  let created = 0, merged = 0;
  for (const g of Object.values(groups)) {
    const { rows: existingPkg } = await pool.query('SELECT id FROM surgery_packages WHERE lower(name)=lower($1)', [g.name]);
    if (existingPkg.length) {
      const pkgId = existingPkg[0].id;
      for (const it of g.items) {
        const { rows: existingItem } = await pool.query('SELECT id, qty FROM surgery_package_items WHERE package_id=$1 AND catalog_id=$2', [pkgId, it.catalogId]);
        if (existingItem.length) {
          await pool.query('UPDATE surgery_package_items SET qty=$1 WHERE id=$2', [existingItem[0].qty + it.qty, existingItem[0].id]);
        } else {
          await pool.query('INSERT INTO surgery_package_items (id, package_id, catalog_id, qty) VALUES ($1,$2,$3,$4)', [uid('pki'), pkgId, it.catalogId, it.qty]);
        }
      }
      merged++;
    } else {
      const pkgId = uid('pkg');
      await pool.query('INSERT INTO surgery_packages (id, name) VALUES ($1,$2)', [pkgId, g.name]);
      for (const it of g.items) {
        await pool.query('INSERT INTO surgery_package_items (id, package_id, catalog_id, qty) VALUES ($1,$2,$3,$4)', [uid('pki'), pkgId, it.catalogId, it.qty]);
      }
      created++;
    }
  }
  res.status(201).json({ created, merged, missingCodes: [...missingCodes] });
});

module.exports = router;
