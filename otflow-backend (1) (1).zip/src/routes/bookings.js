const express = require('express');
const multer = require('multer');
const pdfParse = require('pdf-parse');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { uid, bookingRowToApi } = require('../utils/helpers');

const router = express.Router();
router.use(requireAuth);
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

function canUploadOtList(user) {
  return ['admin', 'consultant', 'superadmin'].includes(user.role);
}

function normOt(s) { return (s || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }

function parseBookingBlock(raw) {
  const clean = raw.replace(/\s+/g, ' ').trim();
  const get = re => { const m = clean.match(re); return m ? m[1].trim() : ''; };
  const name = get(/PATIENT NAME\s*:\s*(.*?)\s*REG NO/i);
  const regNo = get(/REG NO\s*:\s*([0-9\s]+?)\s*IPNO/i).replace(/\s+/g, '');
  const ipNo = get(/IPNO\s*:\s*(\S+)/i);
  const ageSexRaw = get(/AGE\s*\/\s*SEX\s*:\s*([0-9]*\s*\/\s*[MFmf]?)/i).replace(/\s+/g, '');
  const [age = '', sexRaw = ''] = ageSexRaw.split('/');
  const bedNo = get(/BED NO\s*:\s*(\S+)/i);
  const wardText = get(/WARD\s*:\s*(.*?)\s*BLOOD GROUP/i);
  const bookingNo = get(/BOOKING NO\s*:\s*(\S+)/i);
  const otMatch = clean.match(/\bOT-?\s?(\d+)\b/i);
  const otText = otMatch ? `OT-${otMatch[1]}` : '';
  const timeMatch = clean.match(/(\d{1,2}:\d{2}\s*[APap][Mm])/);
  const time = timeMatch ? timeMatch[1].toUpperCase().replace(/\s+/, ' ') : '';
  const surgeonMatch = clean.match(/Dr\.?\s+[A-Z][A-Za-z]*(?:\s+[A-Z][A-Za-z]*){0,3}/);
  const surgeon = surgeonMatch ? surgeonMatch[0].trim() : '';
  let procedure = '';
  const bnIdx = clean.search(/BOOKING NO\s*:\s*\S+/i);
  if (bnIdx >= 0) {
    let seg = clean.slice(bnIdx).replace(/BOOKING NO\s*:\s*\S+\s*/i, '');
    seg = seg.replace(/^OT-?\s?\d+\s*/i, '').replace(/^\d+\s+/, '');
    if (surgeon) seg = seg.split(surgeon)[0];
    procedure = seg.replace(/\s{2,}/g, ' ').trim();
  }
  return { name, regNo, ipNo, age, sex: sexRaw.toUpperCase(), bedNo, wardText, bookingNo, otText, time, surgeon, procedure };
}

router.get('/', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM bookings ORDER BY time');
  res.json(rows.map(bookingRowToApi));
});

// Upload PDF -> return parsed rows for review (nothing saved yet)
router.post('/parse-pdf', requireAuth, upload.single('file'), async (req, res) => {
  if (!canUploadOtList(req.user)) return res.status(403).json({ error: 'Only Super Admin, Admin, or Consultant can upload an OT list' });
  if (!req.file) return res.status(400).json({ error: 'No PDF uploaded' });
  try {
    const data = await pdfParse(req.file.buffer);
    const text = data.text;
    const blocks = text.split(/(?=PATIENT NAME\s*:)/i).map(b => b.trim()).filter(b => /PATIENT NAME\s*:/i.test(b) && b.length > 20);
    const rows = blocks.map(parseBookingBlock);
    res.json({ rows });
  } catch (err) {
    res.status(500).json({ error: `Could not read PDF: ${err.message}` });
  }
});

// Commit reviewed rows (each optionally admits a patient immediately)
router.post('/import', requireAuth, async (req, res) => {
  if (!canUploadOtList(req.user)) return res.status(403).json({ error: 'Only Super Admin, Admin, or Consultant can import bookings' });
  const { rows } = req.body || {};
  if (!Array.isArray(rows)) return res.status(400).json({ error: 'rows array required' });
  const client = await pool.connect();
  const created = [];
  try {
    await client.query('BEGIN');
    for (const r of rows) {
      let otId = r.otId || null;
      if (!otId && r.otText) {
        const { rows: otRows } = await client.query('SELECT id, name FROM ots');
        const match = otRows.find(o => normOt(o.name) === normOt(r.otText));
        if (match) otId = match.id;
      }
      const bookingId = uid('bk');
      await client.query(
        `INSERT INTO bookings (id, name, reg_no, ip_no, age, sex, bed_no, ward_text, booking_no, ot_text, ot_id, time, surgeon, procedure, status)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`,
        [bookingId, r.name, r.regNo, r.ipNo, r.age, r.sex, r.bedLabel || r.bedNo, r.wardText, r.bookingNo,
         r.otText, otId, r.time, r.surgeon, r.procedure, r.admitNow ? 'admitted' : 'scheduled']
      );
      if (r.admitNow && r.name) {
        const patientId = uid('pt');
        await client.query(
          `INSERT INTO patients (id, name, uhid, ward_id, bed_label, age, sex, surgery_type, surgeon,
             status, booking_id, booking_no, ward_in, activity)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'ward',$10,$11,$12,$13)`,
          [patientId, r.name, r.regNo || r.ipNo || null, r.wardId || null, r.bedLabel || r.bedNo || null,
           r.age || null, r.sex || null, r.procedure || null, '', bookingId, r.bookingNo || null,
           req.body.wardInTime || new Date().toISOString(),
           JSON.stringify([{ text: `Admitted to ward from OT Schedule import by ${req.user.full_name}`, at: new Date().toISOString(), by: req.user.full_name }])]
        );
        await client.query('UPDATE bookings SET linked_patient_id=$1 WHERE id=$2', [patientId, bookingId]);
        created.push(patientId);
      }
    }
    await client.query('COMMIT');
  } catch (err) { await client.query('ROLLBACK'); throw err; } finally { client.release(); }
  res.status(201).json({ importedBookings: rows.length, admittedPatients: created.length });
});

router.delete('/', requireAuth, async (req, res) => {
  if (!canUploadOtList(req.user)) return res.status(403).json({ error: 'Only Super Admin, Admin, or Consultant can clear the OT Schedule list' });
  await pool.query('DELETE FROM bookings');
  res.status(204).end();
});

router.delete('/:id', requireAuth, async (req, res) => {
  if (!canUploadOtList(req.user)) return res.status(403).json({ error: 'Insufficient permissions' });
  await pool.query('DELETE FROM bookings WHERE id=$1', [req.params.id]);
  res.status(204).end();
});

module.exports = router;
