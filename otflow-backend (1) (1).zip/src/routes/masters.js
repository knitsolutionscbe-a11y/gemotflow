const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { uid } = require('../utils/helpers');

const router = express.Router();
router.use(requireAuth);

const TYPES = {
  anesthesiaTypes: 'anesthesia_type',
  anesthetists: 'anesthetist',
  drugs: 'drug',
  otItems: 'ot_item'
};

router.get('/', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM masters ORDER BY value');
  const out = { anesthesiaTypes: [], anesthetists: [], drugs: [], otItems: [] };
  const reverse = Object.fromEntries(Object.entries(TYPES).map(([k, v]) => [v, k]));
  rows.forEach(r => { const key = reverse[r.type]; if (key) out[key].push(r.value); });
  res.json(out);
});

router.post('/:type', requireAuth, async (req, res) => {
  const dbType = TYPES[req.params.type];
  if (!dbType) return res.status(400).json({ error: 'Unknown master type' });
  const { value } = req.body || {};
  if (!value) return res.status(400).json({ error: 'Value is required' });
  const id = uid('m');
  await pool.query(
    'INSERT INTO masters (id, type, value) VALUES ($1,$2,$3) ON CONFLICT (type, value) DO NOTHING',
    [id, dbType, value]
  );
  res.status(201).json({ type: req.params.type, value });
});

router.delete('/:type/:value', requireRole('superadmin', 'admin'), async (req, res) => {
  const dbType = TYPES[req.params.type];
  if (!dbType) return res.status(400).json({ error: 'Unknown master type' });
  await pool.query('DELETE FROM masters WHERE type=$1 AND value=$2', [dbType, decodeURIComponent(req.params.value)]);
  res.status(204).end();
});

module.exports = router;
