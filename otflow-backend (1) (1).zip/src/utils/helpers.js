function uid(prefix) {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

// Convert a camelCase-friendly JS object of a patient row into API shape.
function patientRowToApi(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    uhid: row.uhid,
    bookingNo: row.booking_no,
    wardId: row.ward_id,
    roomId: row.room_id,
    bedLabel: row.bed_label,
    age: row.age,
    sex: row.sex,
    surgeryType: row.surgery_type,
    surgeon: row.surgeon,
    anesthesiaType: row.anesthesia_type,
    anesthetist: row.anesthetist,
    drugsUsed: row.drugs_used || [],
    otItemsUsedList: row.ot_items_used || [],
    recoveryNotes: row.recovery_notes,
    pendingPreopId: row.pending_preop_id,
    assignedPreopId: row.assigned_preop_id,
    pendingOtId: row.pending_ot_id,
    assignedOtId: row.assigned_ot_id,
    otNameSnapshot: row.ot_name_snapshot,
    bookingId: row.booking_id,
    status: row.status,
    caseCancelled: row.case_cancelled,
    cancelReason: row.cancel_reason,
    cancelledAt: row.cancelled_at,
    cancelledBy: row.cancelled_by,
    emergencyAdmission: row.emergency_admission,
    emergencyReason: row.emergency_reason,
    emergencyAdmittedBy: row.emergency_admitted_by,
    emergencyAdmittedAt: row.emergency_admitted_at,
    preopVitalsLog: row.preop_vitals_log || [],
    recoveryVitalsLog: row.recovery_vitals_log || [],
    activity: row.activity || [],
    itemOrders: row.itemOrders || [],
    timestamps: {
      wardIn: row.ward_in,
      sentToPreopAt: row.sent_to_preop_at,
      preopIn: row.preop_in,
      sentToOtAt: row.sent_to_ot_at,
      otIn: row.ot_in,
      anesStart: row.anes_start,
      surgStart: row.surg_start,
      surgEnd: row.surg_end,
      anesEnd: row.anes_end,
      otOut: row.ot_out,
      recoveryIn: row.recovery_in,
      sentToWardAt: row.sent_to_ward_at,
      wardReturn: row.ward_return
    },
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function bookingRowToApi(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    regNo: row.reg_no,
    ipNo: row.ip_no,
    age: row.age,
    sex: row.sex,
    bedNo: row.bed_no,
    wardText: row.ward_text,
    bookingNo: row.booking_no,
    otText: row.ot_text,
    otId: row.ot_id,
    time: row.time,
    surgeon: row.surgeon,
    procedure: row.procedure,
    status: row.status,
    linkedPatientId: row.linked_patient_id,
    importedAt: row.imported_at
  };
}

function userRowToApi(row) {
  if (!row) return null;
  return {
    id: row.id,
    username: row.username,
    fullName: row.full_name,
    role: row.role,
    department: row.department,
    assignedOtId: row.assigned_ot_id,
    assignedWardId: row.assigned_ward_id,
    active: row.active,
    createdAt: row.created_at,
    createdBy: row.created_by
  };
}

function itemOrderRowToApi(row) {
  if (!row) return null;
  return {
    id: row.id,
    catalogId: row.catalog_id,
    itemCode: row.item_code,
    name: row.description,
    uom: row.uom,
    itemGroup: row.item_group,
    itemType: row.item_type,
    qty: row.qty,
    usedQty: row.used_qty,
    status: row.status,
    orderedBy: row.ordered_by,
    orderedAt: row.ordered_at,
    issuedBy: row.issued_by,
    issuedAt: row.issued_at,
    receivedBy: row.received_by,
    receivedAt: row.received_at,
    billedAt: row.billed_at,
    returnAcknowledgedBy: row.return_acknowledged_by,
    returnAcknowledgedAt: row.return_acknowledged_at
  };
}
function catalogRowToApi(row) {
  if (!row) return null;
  return { id: row.id, sNo: row.s_no, itemCode: row.item_code, description: row.description, uom: row.uom, itemGroup: row.item_group, itemType: row.item_type };
}

module.exports = { uid, patientRowToApi, bookingRowToApi, userRowToApi, itemOrderRowToApi, catalogRowToApi };
