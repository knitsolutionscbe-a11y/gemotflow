const jwt = require('jsonwebtoken');
const pool = require('../db');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

async function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing authorization token' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const { rows } = await pool.query('SELECT * FROM users WHERE id = $1', [payload.sub]);
    const user = rows[0];
    if (!user || !user.active) return res.status(401).json({ error: 'Account not found or disabled' });
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient role permissions' });
    }
    next();
  };
}

// Super Admin / Admin bypass department checks entirely (mirrors frontend hasDept()).
function requireDept(dept) {
  return (req, res, next) => {
    const u = req.user;
    if (!u) return res.status(401).json({ error: 'Not authenticated' });
    if (u.role === 'superadmin' || u.role === 'admin') return next();
    if (u.department === 'all' || u.department === dept) return next();
    return res.status(403).json({ error: `${dept} department staff only` });
  };
}

// Resource-scoped checks mirroring the frontend's hasOtScope()/hasWardScope():
// a 'ot'/'ward' department user with assigned_ot_id/assigned_ward_id set is
// restricted to only that specific theatre/ward; left blank, they're a
// manager with access to every theatre/ward in that department.
function hasOtScope(user, otId) {
  if (user.role === 'superadmin' || user.role === 'admin') return true;
  if (user.department === 'all') return true;
  if (user.department !== 'ot') return false;
  if (!user.assigned_ot_id) return true;
  return user.assigned_ot_id === otId;
}
function hasWardScope(user, wardId) {
  if (user.role === 'superadmin' || user.role === 'admin') return true;
  if (user.department === 'all') return true;
  if (user.department !== 'ward') return false;
  if (!user.assigned_ward_id) return true;
  return user.assigned_ward_id === wardId;
}
// otIdParam/wardIdParam: a function (req) => id, since the relevant OT/ward is
// usually only known after loading the patient/resource the request targets.
function requireOtScope(otIdParam) {
  return (req, res, next) => {
    const otId = otIdParam(req);
    if (!hasOtScope(req.user, otId)) return res.status(403).json({ error: 'That theatre is outside your assigned scope' });
    next();
  };
}
function requireWardScope(wardIdParam) {
  return (req, res, next) => {
    const wardId = wardIdParam(req);
    if (!hasWardScope(req.user, wardId)) return res.status(403).json({ error: 'That ward is outside your assigned scope' });
    next();
  };
}

module.exports = { requireAuth, requireRole, requireDept, hasOtScope, hasWardScope, requireOtScope, requireWardScope, JWT_SECRET };
