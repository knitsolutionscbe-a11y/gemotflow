// Runs schema.sql + every migration_*.sql file against DATABASE_URL/PG* env
// vars, using the same 'pg' connection the app already depends on. This
// exists because some shared-hosting Node.js setups (cPanel's Node.js
// Selector, for example) don't give you a `psql` command-line client even
// though the app itself can talk to Postgres fine — so this avoids needing
// one at all. Safe to re-run: schema.sql only matters on a brand-new,
// empty database, and every migration_*.sql file uses IF NOT EXISTS /
// ON CONFLICT so re-running them is a no-op.

const fs = require('fs');
const path = require('path');
const pool = require('./db');

async function runFile(filename) {
  const fullPath = path.join(__dirname, filename);
  if (!fs.existsSync(fullPath)) {
    console.log(`(skipping ${filename} — not found)`);
    return;
  }
  const sql = fs.readFileSync(fullPath, 'utf8');
  console.log(`Running ${filename} ...`);
  try {
    await pool.query(sql);
    console.log(`  done.`);
  } catch (err) {
    // schema.sql will fail with "already exists" on a database that's been
    // set up before — that's fine, it just means this step was already done.
    if (/already exists/i.test(err.message)) {
      console.log(`  already applied, skipping (${err.message})`);
    } else {
      throw err;
    }
  }
}

async function main() {
  await runFile('schema.sql');
  const migrationFiles = fs.readdirSync(__dirname)
    .filter(f => /^migration_\d+\.sql$/.test(f))
    .sort();
  for (const f of migrationFiles) {
    await runFile(f);
  }
  console.log('All migrations applied.');
  await pool.end();
}

main().catch(err => {
  console.error('Migration failed:', err.message);
  process.exit(1);
});
