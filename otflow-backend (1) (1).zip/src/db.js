const { Pool } = require('pg');
require('dotenv').config();

const connectionString = process.env.DATABASE_URL ||
  `postgresql://${process.env.PGUSER || 'otflow'}:${process.env.PGPASSWORD || 'otflow_dev_pw'}@${process.env.PGHOST || 'localhost'}:${process.env.PGPORT || 5432}/${process.env.PGDATABASE || 'otflow'}`;

// Hosted Postgres providers (Neon, Render Postgres, Heroku, etc.) require an
// SSL connection and present a certificate outside Node's default trust
// store — rejectUnauthorized:false is the standard, expected way to connect
// to these specific managed providers from node-postgres. Local development
// (localhost) skips SSL entirely, since a local Postgres isn't listening for it.
const isLocal = /localhost|127\.0\.0\.1/.test(connectionString);
const pool = new Pool({
  connectionString,
  ssl: isLocal ? false : { rejectUnauthorized: false }
});

module.exports = pool;
