-- Migration 003: track when OT Store has physically taken back a "returned"
-- (ordered but not used) item, so returned items don't just disappear from
-- view the moment OT marks them unused.

ALTER TABLE patient_item_orders ADD COLUMN IF NOT EXISTS return_acknowledged_by TEXT;
ALTER TABLE patient_item_orders ADD COLUMN IF NOT EXISTS return_acknowledged_at TIMESTAMPTZ;
